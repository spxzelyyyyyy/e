#include "playertick.h"

#include <array>
#include <vector>

#include <cheat/features/weaponutils.h>
#include <cheat/cache/playercache.h>
#include <cheat/tick/pickuptick.h>
#include <cheat/sdk/sdk.h>
#include <drawing/drawing.h>
#include <config/config.h>
#include <cheat/core.h>
#include <utils/math.h>

namespace Tick {
namespace Player {

// --- Player Utility Data -------------------------------------------

constexpr std::array<std::pair<Cache::Player::BoneIdx, Cache::Player::BoneIdx>, 100> BoneConnections = {
    // Spine & Head
    std::pair(Cache::Player::BoneIdx::Head, Cache::Player::BoneIdx::Neck),
    std::pair(Cache::Player::BoneIdx::Neck, Cache::Player::BoneIdx::Chest),
    std::pair(Cache::Player::BoneIdx::Chest, Cache::Player::BoneIdx::Pelvis),

    // Left Arm
    std::pair(Cache::Player::BoneIdx::Chest, Cache::Player::BoneIdx::L_Shoulder),
    std::pair(Cache::Player::BoneIdx::L_Shoulder, Cache::Player::BoneIdx::L_Elbow),
    std::pair(Cache::Player::BoneIdx::L_Elbow, Cache::Player::BoneIdx::L_Hand),

    // Right Arm
    std::pair(Cache::Player::BoneIdx::Chest, Cache::Player::BoneIdx::R_Shoulder),
    std::pair(Cache::Player::BoneIdx::R_Shoulder, Cache::Player::BoneIdx::R_Elbow),
    std::pair(Cache::Player::BoneIdx::R_Elbow, Cache::Player::BoneIdx::R_Hand),

    // Left Leg
    std::pair(Cache::Player::BoneIdx::Pelvis, Cache::Player::BoneIdx::L_Thigh),
    std::pair(Cache::Player::BoneIdx::L_Thigh, Cache::Player::BoneIdx::L_Knee),
    std::pair(Cache::Player::BoneIdx::L_Knee, Cache::Player::BoneIdx::L_Foot),

    // Right Leg
    std::pair(Cache::Player::BoneIdx::Pelvis, Cache::Player::BoneIdx::R_Thigh),
    std::pair(Cache::Player::BoneIdx::R_Thigh, Cache::Player::BoneIdx::R_Knee),
    std::pair(Cache::Player::BoneIdx::R_Knee, Cache::Player::BoneIdx::R_Foot)};

// --- Public Tick Functions -----------------------------------------

void TickGameThread() {
    Cache::Player::UpdateCache();
}

void TickRenderThread() {
    const auto& PlayerConfig = Config::g_Config.Visuals.Player;
    const auto& ColorConfig = Config::g_Config.Color;

    float FontSize = PlayerConfig.FontSize;

    for (const auto& [_, Info] : Cache::Player::GetCachedPlayers()) {
        if (Info.Pawn == SDK::GetLocalPawn() || Info.DistanceM >= Config::g_Config.Visuals.Player.MaxDistance ||
            Info.TeamIndex == Core::g_LocalTeamIndex || Info.IsDead)
            continue;

        SDK::FLinearColor PrimaryColor =
            Info.HeadVisible ? ColorConfig.PrimaryColorVisible : ColorConfig.PrimaryColorHidden;
        SDK::FLinearColor SecondaryColor =
            Info.HeadVisible ? ColorConfig.SecondaryColorVisible : ColorConfig.SecondaryColorHidden;

        if (PlayerConfig.Box) {
            if (PlayerConfig.FilledBox && (PlayerConfig.BoxType == Config::ConfigData::BoxType::Full ||
                                           PlayerConfig.BoxType == Config::ConfigData::BoxType::Cornered)) {
                Drawing::RectFilled(Info.BoundTopLeft, (Info.BoundBottomRight - Info.BoundTopLeft),
                                    PlayerConfig.FilledBoxColor);
            }

            switch (PlayerConfig.BoxType) {
            case Config::ConfigData::BoxType::Full:
                Drawing::Rect(Info.BoundTopLeft, (Info.BoundBottomRight - Info.BoundTopLeft), PrimaryColor,
                              PlayerConfig.BoxThickness);
                break;
            case Config::ConfigData::BoxType::Cornered:
                Drawing::CorneredRect(Info.BoundTopLeft, (Info.BoundBottomRight - Info.BoundTopLeft), PrimaryColor,
                                      PlayerConfig.BoxThickness);
                break;
            case Config::ConfigData::BoxType::Full3D:
                Drawing::Rect3D(Info.BoundCorners2D, PrimaryColor, PlayerConfig.BoxThickness, true, 1.f,
                                SDK::FLinearColor::Black, PlayerConfig.FilledBox, PlayerConfig.FilledBoxColor);
                break;
            }
        }

        if (PlayerConfig.Skeleton) {
            Drawing::BeginBatchedLines(BoneConnections.size());
            for (const auto& Pair : BoneConnections) {
                Drawing::Line(Info.BoneScreenPos[static_cast<int>(Pair.first)],
                              Info.BoneScreenPos[static_cast<int>(Pair.second)], SecondaryColor,
                              PlayerConfig.SkeletonThickness);
            }
            Drawing::EndBatchedLines();
        }

        if (PlayerConfig.ChineseHat) {
            // Optional visibility gate
            if (!PlayerConfig.ChineseHatVisibleOnly || Info.HeadVisible) {
                // Compute robust up/forward/right basis: use world up to prevent tilt
                SDK::FVector headPos3D = Info.BoneWorldPos[static_cast<int>(Cache::Player::BoneIdx::Head)];
                SDK::FVector neck3D = Info.BoneWorldPos[static_cast<int>(Cache::Player::BoneIdx::Neck)];
                SDK::FVector pelvis3D = Info.BoneWorldPos[static_cast<int>(Cache::Player::BoneIdx::Pelvis)];

                // Use world up to keep hat straight; blend slightly toward neck->head to follow pitch without roll
                SDK::FVector worldUp(0.f, 0.f, 1.f);
                SDK::FVector boneUp = headPos3D - neck3D;
                if (!boneUp.Normalize()) boneUp = worldUp;
                // Blend 30% bone up, 70% world up for gentle pitch following but stable roll
                SDK::FVector up = (boneUp * 0.3f + worldUp * 0.7f);
                up.Normalize();

                SDK::FVector forward = headPos3D - pelvis3D;
                if (!forward.Normalize()) forward = SDK::FVector(1.f, 0.f, 0.f);
                // Recompute right and orthonormalize to remove roll
                SDK::FVector right = up.Cross(forward);
                if (!right.Normalize()) right = SDK::FVector(1.f, 0.f, 0.f);
                forward = right.Cross(up);
                forward.Normalize();

                const float arcRadius = std::max(5.f, PlayerConfig.ChineseHatRadius);
                const float arcHeight = std::max(1.f, PlayerConfig.ChineseHatHeight);
                const int   arcSegments = std::clamp(PlayerConfig.ChineseHatSegments, 8, 128);

                SDK::FVector  coneTip3D = headPos3D + up * arcHeight;
                SDK::FVector2D coneTip2D = SDK::Project(coneTip3D);

                std::vector<SDK::FVector2D> arcPoints;
                arcPoints.reserve(arcSegments + 1);
                for (int i = 0; i <= arcSegments; ++i) {
                    float angle = 2.f * 3.14159265359f * (static_cast<float>(i) / arcSegments);
                    SDK::FVector offset = (right * std::cos(angle) + forward * std::sin(angle)) * arcRadius;
                    SDK::FVector basePoint3D = coneTip3D + offset - up * arcHeight;
                    SDK::FVector2D basePoint2D = SDK::Project(basePoint3D);

                    if (basePoint2D.X > 0 && basePoint2D.Y > 0)
                        arcPoints.push_back(basePoint2D);
                }

                if (!arcPoints.empty() && coneTip2D.X > 0 && coneTip2D.Y > 0) {
                    SDK::FLinearColor color = PrimaryColor; // match per-target color/visibility
                    for (size_t i = 0; i + 1 < arcPoints.size(); ++i) {
                        Drawing::Line(arcPoints[i], arcPoints[i + 1], color, 1.25f);
                    }
                    Drawing::Line(arcPoints.back(), arcPoints.front(), color, 1.25f);

                    for (const auto& p : arcPoints) {
                        Drawing::Line(coneTip2D, p, color, 1.0f);
                    }
                }
            }
        }

        if (PlayerConfig.Tracer) {
            SDK::FVector2D TracerStart, TracerEnd;

            switch (PlayerConfig.TracerStart) {
            case Config::ConfigData::TracerPos::Bottom:
                TracerStart =
                    SDK::FVector2D(static_cast<float>(Core::g_ScreenCenterX), static_cast<float>(Core::g_ScreenSizeY));
                break;
            case Config::ConfigData::TracerPos::Middle:
                TracerStart = SDK::FVector2D(static_cast<float>(Core::g_ScreenCenterX),
                                             static_cast<float>(Core::g_ScreenCenterY));
                break;
            case Config::ConfigData::TracerPos::Top:
                TracerStart = SDK::FVector2D(static_cast<float>(Core::g_ScreenCenterX), 0.f);
                break;
            }

            switch (PlayerConfig.TracerEnd) {
            case Config::ConfigData::TracerPos::Bottom:
                TracerEnd = Info.BoxBottom;
                break;
            case Config::ConfigData::TracerPos::Middle:
                TracerEnd = Info.BoxMiddle;
                break;
            case Config::ConfigData::TracerPos::Top:
                TracerEnd = Info.BoxTop;
                break;
            }

            // Screen bounds check for tracer endpoints
            bool TracerStartValid = (TracerStart.X >= 0 && TracerStart.X <= Core::g_ScreenSizeX && 
                                   TracerStart.Y >= 0 && TracerStart.Y <= Core::g_ScreenSizeY);
            bool TracerEndValid = (TracerEnd.X >= 0 && TracerEnd.X <= Core::g_ScreenSizeX && 
                                 TracerEnd.Y >= 0 && TracerEnd.Y <= Core::g_ScreenSizeY);

            // Only draw tracer if both endpoints are within screen bounds
            if (TracerStartValid && TracerEndValid) {
                Drawing::Line(TracerStart, TracerEnd, PrimaryColor, PlayerConfig.TracerThickness);
            }
        }

        if (PlayerConfig.HeadCircle) {
            SDK::FVector2D head2D = Info.BoneScreenPos[static_cast<int>(Cache::Player::BoneIdx::Head)];
            if ((!PlayerConfig.HeadCircleVisibleOnly || Info.HeadVisible) && head2D.X > 0 && head2D.Y > 0) {
                float r = PlayerConfig.HeadCircleRadius > 0.f ? PlayerConfig.HeadCircleRadius : 3.f;
                Drawing::Circle(head2D, r, 60, SDK::FLinearColor(1.f, 0.f, 0.75f, 1.f), 1.5f);
            }
        }

        SDK::FVector2D TopTextPos = {Info.BoxTop.X, Info.BoxTop.Y - FontSize - 2.f};
        if (PlayerConfig.Name && !Info.PlayerName.empty()) {
            Drawing::Text(Info.PlayerName.c_str(), TopTextPos, PrimaryColor, FontSize, true, false);
            TopTextPos.Y -= 2.f + FontSize;
        }
        if (PlayerConfig.Platform && !Info.Platform.empty()) {
            Drawing::Text(Info.Platform.c_str(), TopTextPos, PrimaryColor, FontSize, true, false);
            TopTextPos.Y -= 2.f + FontSize;
        }

        SDK::FVector2D BottomTextPos = {Info.BoxBottom.X, Info.BoxBottom.Y + 2.f};
        if (PlayerConfig.CurrentWeapon && !Info.WeaponName.empty()) {
            char Buffer[64];
            if (Info.BulletsPerClip) {
                snprintf(Buffer, sizeof(Buffer), "%s [%d/%d]", Info.WeaponName.c_str(), Info.AmmoCount,
                         Info.BulletsPerClip);
            } else {
                snprintf(Buffer, sizeof(Buffer), "%s", Info.WeaponName.c_str());
            }

            Drawing::Text(Buffer, BottomTextPos, Tick::Pickup::GetTierColor(Info.WeaponTier), FontSize, true, false);
            BottomTextPos.Y += 2.f + FontSize;
        }
        if (PlayerConfig.Distance) {
            char Buffer[64];
            snprintf(Buffer, sizeof(Buffer), "%d m", static_cast<int>(Info.DistanceM));

            Drawing::Text(Buffer, BottomTextPos, PrimaryColor, FontSize, true, false);
            BottomTextPos.Y += 2.f + FontSize;
        }

        if (PlayerConfig.OSI && !Info.IsOnScreen) {
            SDK::FVector2D TipPoint, BasePoint1, BasePoint2;
            SDK::FVector   HeadPosition = Info.RootWorldLocation;
            SDK::FVector   HeadPosition2D = SDK::Project3D(HeadPosition);
            if (HeadPosition2D.Z <= 0.f) {
                HeadPosition2D.X *= -1.f;
                HeadPosition2D.Y *= -1.f;
                HeadPosition2D.X += Core::g_ScreenSizeX;
                HeadPosition2D.Y += Core::g_ScreenSizeY;
            }

            float CurrentFOV = 0.f;
            if (PlayerConfig.OSIMatchFOV) {
                CurrentFOV = Features::WeaponUtils::GetState().Config.FOV;
            } else {
                CurrentFOV = PlayerConfig.OSIFOV;
            }

            if (!CurrentFOV) {
                CurrentFOV = PlayerConfig.OSIFOV;
            }

            float          Radius = CurrentFOV * Core::g_PixelsPerDegree;
            SDK::FVector2D DirectionToPlayer =
                SDK::FVector2D(HeadPosition2D.X - Core::g_ScreenCenterX, HeadPosition2D.Y - Core::g_ScreenCenterY);
            float Magnitude =
                std::sqrt(DirectionToPlayer.X * DirectionToPlayer.X + DirectionToPlayer.Y * DirectionToPlayer.Y);
            DirectionToPlayer = DirectionToPlayer / Magnitude;

            float          Angle = std::atan2(DirectionToPlayer.Y, DirectionToPlayer.X);
            SDK::FVector2D IndicatorPosition = {Core::g_ScreenCenterX + std::cos(Angle) * Radius,
                                                Core::g_ScreenCenterY + std::sin(Angle) * Radius};

            TipPoint = IndicatorPosition + DirectionToPlayer * PlayerConfig.OSISize;
            BasePoint1 =
                IndicatorPosition + SDK::FVector2D(-DirectionToPlayer.Y, DirectionToPlayer.X) * PlayerConfig.OSISize;
            BasePoint2 =
                IndicatorPosition - SDK::FVector2D(-DirectionToPlayer.Y, DirectionToPlayer.X) * PlayerConfig.OSISize;

            Drawing::Triangle(BasePoint1, BasePoint2, TipPoint, true, PrimaryColor);
        }
    }
}

} // namespace Player
} // namespace Tick

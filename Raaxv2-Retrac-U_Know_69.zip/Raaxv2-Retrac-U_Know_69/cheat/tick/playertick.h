#pragma once

namespace Tick {
namespace Player {

// --- Public Tick Functions -----------------------------------------

void TickGameThread();
void TickRenderThread();

} // namespace Player
} // namespace Tick

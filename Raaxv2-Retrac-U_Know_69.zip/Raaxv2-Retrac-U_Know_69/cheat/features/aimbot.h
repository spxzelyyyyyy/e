#pragma once

namespace SDK {
struct FTransform;
struct FVector;
struct FRotator;
}

namespace Features {
namespace Aimbot {

// --- Public Tick Functions -----------------------------------------

void TickGameThread();
void TickRenderThread();

// --- Compatibility/Callback-style APIs ------------------------------

// Convenience function to apply aimbot based on the aim key. This mirrors the
// behavior expected by external scripts, and will suppress visible input when
// Silent Aim Only is enabled.
void AimbotTarget();

// Callback to adjust bullet transform for BulletTP/BulletTPV2.
void CalculateShotCallback(SDK::FTransform* BulletTransform);

// Callback to provide a silent rotation for ballistic prediction without
// changing the actual camera.
void GetPlayerViewpointCallback(SDK::FVector* Location, SDK::FRotator* Rotation);

} // namespace Aimbot
} // namespace Features

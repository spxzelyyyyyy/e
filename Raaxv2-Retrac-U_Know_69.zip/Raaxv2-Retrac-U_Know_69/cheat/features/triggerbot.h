#pragma once

namespace Features {
namespace TriggerBot {

// --- Public Tick Functions -----------------------------------------

void TickGameThread();
void TickRenderThread();

} // namespace TriggerBot
} // namespace Features

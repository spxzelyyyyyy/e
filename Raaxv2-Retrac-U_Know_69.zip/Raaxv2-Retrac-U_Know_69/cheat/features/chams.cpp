#include "chams.h"

#include <vector>
#include <algorithm>
#include <chrono>
#include <unordered_map>

#include <cheat/cache/playercache.h>
#include <cheat/core.h>
#include <cheat/sdk/sdk.h>
#include <config/config.h>
#include <utils/error.h>

namespace Features {
namespace Chams {

// --- Chams State Management ----------------------------------------

struct ChamsState {
    std::vector<SDK::TArray<SDK::UMaterialInterface*>> OriginalMaterials;
    SDK::UMaterialInstanceDynamic*                     ChamsMaterial = nullptr;
    bool                                               HasChamsApplied = false;
    std::chrono::steady_clock::time_point              LastApplyTime;
};
std::unordered_map<SDK::AFortPlayerPawn*, ChamsState> ChamsAppliedPlayers;

// Shared dynamic material instance reused across all players
static SDK::UMaterialInstanceDynamic* g_SharedChamsMID = nullptr;

// --- Chams Utility Functions ---------------------------------------

static SDK::UMaterial* GetMaterial() {
    static SDK::UMaterial* Material = SDK::UObject::FindObjectFast<SDK::UMaterial>("RezIn_Master");
    return Material; // Tolerant: if null, we will simply skip chams instead of crashing
}

static bool IsDynamicMaterialValid(SDK::UMaterialInstanceDynamic* DynamicMaterial) {
    if (!DynamicMaterial || !DynamicMaterial->Class)
        return false;
    return DynamicMaterial->IsA(SDK::UMaterialInstanceDynamic::StaticClass());
}

static SDK::UMaterialInstanceDynamic* GetSharedMaterialInstance() {
    SDK::UMaterial* BaseMat = GetMaterial();
    if (!BaseMat)
        return nullptr;

    if (!IsDynamicMaterialValid(g_SharedChamsMID)) {
        // Use world as context to avoid issues when Pawn is null or changing
        g_SharedChamsMID = SDK::UKismetMaterialLibrary::CreateDynamicMaterialInstance(SDK::GetWorld(), BaseMat, SDK::FName());
    }
    return g_SharedChamsMID;
}

static void UpdateMaterialSettings(SDK::UMaterialInstanceDynamic* MaterialInstance, const SDK::FLinearColor& Color,
                                   float EmissionIntensity) {
    if (!MaterialInstance)
        return;

    static SDK::FName ChamsColorParams[] = {SDK::FName(L"WireFrameParameterHighlight"),
                                            SDK::FName(L"WireFrameFadeOffColor"), SDK::FName(L"Top Color"),
                                            SDK::FName(L"Bottom Color")};
    static SDK::FName EmissionParams[] = {SDK::FName(L"Emissive Modulation")};

    for (auto& Param : ChamsColorParams) {
        MaterialInstance->SetVectorParameterValue(Param, Color);
    }
    for (auto& Param : EmissionParams) {
        MaterialInstance->SetScalarParameterValue(Param, EmissionIntensity);
    }
}

static void ApplyChamsToPlayer(SDK::AFortPlayerPawn* Pawn, const SDK::FLinearColor& Color, float EmissionIntensity) {
    if (!Pawn)
        return;

    auto MeshComponents = Pawn->GetCharacterPartSkeletalMeshComponents();
    if (MeshComponents.empty())
        return;

    bool HasMaterialsToReplace = false;
    for (auto* Comp : MeshComponents) {
        if (Comp && Comp->GetMaterials().Num() > 0) {
            HasMaterialsToReplace = true;
            break;
        }
    }

    if (!HasMaterialsToReplace)
        return;

    auto& State = ChamsAppliedPlayers[Pawn];
    if (State.OriginalMaterials.size() != MeshComponents.size())
        State.OriginalMaterials.resize(MeshComponents.size());

    SDK::UMaterialInstanceDynamic* MaterialInstance = GetSharedMaterialInstance();
    if (!IsDynamicMaterialValid(MaterialInstance)) {
        ChamsAppliedPlayers.erase(Pawn);
        return;
    }
    UpdateMaterialSettings(MaterialInstance, Color, EmissionIntensity);

    for (size_t i = 0; i < MeshComponents.size(); i++) {
        SDK::USkeletalMeshComponent* Comp = MeshComponents[i];
        if (!Comp)
            continue;

        if (!State.HasChamsApplied)
            State.OriginalMaterials[i] = Comp->GetMaterials();

        const int slotCount = Comp->GetMaterials().Num();
        for (int j = 0; j < slotCount; j++) {
            Comp->SetMaterial(j, MaterialInstance);
        }
    }

    State.HasChamsApplied = true;
    State.LastApplyTime = std::chrono::steady_clock::now();
}

static void RemoveChamsFromPlayer(SDK::AFortPlayerPawn* Pawn) {
    if (!Pawn)
        return;
    auto It = ChamsAppliedPlayers.find(Pawn);
    if (It == ChamsAppliedPlayers.end() || !It->second.HasChamsApplied)
        return;

    auto& State = It->second;

    auto MeshComponents = Pawn->GetCharacterPartSkeletalMeshComponents();
    for (size_t i = 0; i < MeshComponents.size(); i++) {
        SDK::USkeletalMeshComponent* Comp = MeshComponents[i];
        if (!Comp)
            continue;

        if (i < State.OriginalMaterials.size()) {
            auto& OriginalMaterials = State.OriginalMaterials[i];
            const int maxSlots = std::min(OriginalMaterials.Num(), Comp->GetMaterials().Num());
            for (int j = 0; j < maxSlots; j++) {
                Comp->SetMaterial(j, OriginalMaterials[j]);
            }
        }
    }

    if (State.ChamsMaterial)
        State.ChamsMaterial = nullptr;

    State.HasChamsApplied = false;
}

static void CleanupRemovedPlayers() {
    auto CachedPlayers = Cache::Player::GetCachedPlayers();
    for (auto It = ChamsAppliedPlayers.begin(); It != ChamsAppliedPlayers.end();) {
        if (CachedPlayers.find(It->first) == CachedPlayers.end()) {
            It = ChamsAppliedPlayers.erase(It);
        } else {
            ++It;
        }
    }
}

// --- Public Functions ----------------------------------------------

void Destroy() {
    for (auto& [Pawn, _] : ChamsAppliedPlayers) {
        RemoveChamsFromPlayer(Pawn);
    }

    ChamsAppliedPlayers.clear();
}

void TickGameThread() {
    auto&       Config = Config::g_Config.Visuals.Player;
    static bool LastChamsState = false;

    CleanupRemovedPlayers();

    if (LastChamsState && !Config.Chams) {
        for (auto& [Pawn, _] : ChamsAppliedPlayers) {
            RemoveChamsFromPlayer(Pawn);
        }
    }
    LastChamsState = Config.Chams;

    if (!Config.Chams)
        return;

    SDK::UMaterial* Material = GetMaterial();
    if (!Material)
        return; // Skip safely if material not available on this build
    Material->bDisableDepthTest = Config.ChamsThroughWalls;
    Material->BlendMode = SDK::EBlendMode::BLEND_Additive;
    Material->WireFrame = Config.ChamsWireframe;

    // Keep dynamic material color/emissive up-to-date every tick
    if (SDK::UMaterialInstanceDynamic* MID = GetSharedMaterialInstance()) {
        UpdateMaterialSettings(MID, Config.ChamsColor, Config.ChamsEmissionIntensity);
    }

    constexpr auto ReapplyInterval = std::chrono::seconds(2);
    auto           CurrentTime = std::chrono::steady_clock::now();

    for (const auto& [_, Info] : Cache::Player::GetCachedPlayers()) {
        if (!Config.ChamsOnSelf && Info.Pawn == SDK::GetLocalPawn()) {
            RemoveChamsFromPlayer(Info.Pawn);
            continue;
        }

        auto It = ChamsAppliedPlayers.find(Info.Pawn);
        bool NeedsChams = (It == ChamsAppliedPlayers.end()) || !It->second.HasChamsApplied;
        bool NeedsReapply =
            (It != ChamsAppliedPlayers.end()) && (CurrentTime - It->second.LastApplyTime >= ReapplyInterval);

        if (NeedsChams || NeedsReapply) {
            ApplyChamsToPlayer(Info.Pawn, Config.ChamsColor, Config.ChamsEmissionIntensity);
        }
    }
}

} // namespace Chams
} // namespace Features
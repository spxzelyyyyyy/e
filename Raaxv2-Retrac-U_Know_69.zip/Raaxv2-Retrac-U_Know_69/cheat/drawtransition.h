#pragma once

namespace DrawTransition {

// --- Initialization ------------------------------------------------

bool Init();
void Destroy();

} // namespace DrawTransition
